import UIKit

var myNumber = 1
myNumber = myNumber + 1

// While Loop
var number = 0
while number <= 99 {
 //   print(number)
    number += 1
}
var characterAlive = true
while characterAlive == true {
        //    print("characterAlive")
    characterAlive = false
}
5 > 7
17 < 91
41 == 41
56 != 41
// End While Loop

// for loop

var myFruitArray = ["Banana", "Apple","Orange"]
print(myFruitArray[0])
print(myFruitArray[1])
print(myFruitArray[2])


var myFavoriCaffe = ["Latte","Americano","Latte Mocha"]
for Caffe  in myFavoriCaffe{
    print(Caffe)
}

var myNumbers = [10,20,30,40]
for nun  in myNumbers {
    print(nun / 5)
}

// for mynumberintegar in 1...17{
  //  print(mynumberintegar*5)





