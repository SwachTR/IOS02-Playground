import UIKit

// Aryy
var myFavoriteMovies =
["Harry Potter","Godfather","Citizen Kane","La Dolce Vita","Seven Samurai","In the Mood for Love",5,true] as [Any]

// as -> casting
// any -> any object

//index
myFavoriteMovies[0]
myFavoriteMovies[1]
myFavoriteMovies[2]
myFavoriteMovies[3]
myFavoriteMovies[4]
myFavoriteMovies[5]
myFavoriteMovies[6]
myFavoriteMovies[7]

var myStringArry = ["Test","Test01","Test02"]
myStringArry[0].uppercased()
myStringArry.count
myStringArry[myStringArry.count - 1]

myStringArry.last
myStringArry.sort()


var myNumberArry = [1,2,3,4,5,6]
myNumberArry.append(19)
myNumberArry [0]
myNumberArry [0] = 31
myNumberArry [0]
myNumberArry [3]


myNumberArry[0]
myNumberArry.append(7)
myNumberArry.append(8)
myNumberArry.last

// Dictionary
// kry-value pairing


 var myFavoriteDirectors = ["Pulp Fiction" : "Tarantino", "Lock, Stock" : "Guy Ritchie", "The Dark Knight": "Christopher Nolan"]
myFavoriteDirectors ["The Dark Knight"]
myFavoriteDirectors ["Pulp Fiction"]

myFavoriteDirectors ["Pulp Fiction"] = "Quantin Tarantino"
print(myFavoriteDirectors)

myFavoriteDirectors["Seven Samuria"] = "Akria Kurisova"
print(myFavoriteDirectors)






