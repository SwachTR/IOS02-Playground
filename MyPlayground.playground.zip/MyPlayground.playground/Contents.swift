import UIKit

// Variables & Constants

// String
var greeting = "Hello, playground"

var mynumber = 5 + 9
var mmynuber = 90 * 60

var userName = "James"
userName.append("Atik")
userName.lowercased()
userName.uppercased()

var userSurname = "Atik"
userName = "Laos"

// integer & doble  & float

// integer
let userAge = 50
let myNumber = 4
userAge / myNumber
 
// doble
let userAgeD = 50.0
let myNumberD = 4.0
userAgeD / myNumberD

// boolean
var myBoolean = false
myBoolean = true

var myString : String = "50"
let anotherNumber : Int = 10

let stringNumber : String = String (20)

// define
let myVaribale : String

// initialization

myVaribale = "Text"
myVaribale.uppercased()
myVaribale.lowercased()















